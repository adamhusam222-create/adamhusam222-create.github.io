// This file contains all exercise data
// You can easily add more exercises by following the same format

export interface Exercise {
  name: string
  videoUrl: string // YouTube embed URL
  primaryMuscle: string
  secondaryMuscles?: string
  technique: string[]
  mistakes: string[]
}

export interface MuscleGroup {
  name: string
  icon: string
  exercises: Exercise[]
}

export const exerciseData: MuscleGroup[] = [
  // ============ CHEST ============
  {
    name: "Chest",
    icon: "💪",
    exercises: [
      {
        name: "Dumbbell Press",
        videoUrl: "https://www.youtube.com/embed/VmB1G1K7v94",
        primaryMuscle: "Chest",
        secondaryMuscles: "Triceps, Shoulders",
        technique: [
          "Lie flat on bench with feet on the floor",
          "Hold dumbbells at chest level, palms facing forward",
          "Press up until arms are extended but not locked",
          "Lower slowly with control to chest level",
        ],
        mistakes: [
          "Flaring elbows too wide (keep 45° angle)",
          "Bouncing weights off chest",
          "Arching back excessively",
        ],
      },
      {
        name: "Incline Press",
        videoUrl: "https://www.youtube.com/embed/8iPEnn-ltC8",
        primaryMuscle: "Upper Chest",
        secondaryMuscles: "Shoulders, Triceps",
        technique: [
          "Set bench to 30-45 degree angle",
          "Keep shoulders back and down",
          "Press dumbbells up in a slight arc",
          "Lower to upper chest area",
        ],
        mistakes: [
          "Setting bench angle too high (becomes shoulder press)",
          "Lifting hips off the bench",
          "Using momentum instead of muscle control",
        ],
      },
      {
        name: "Cable Flyes",
        videoUrl: "https://www.youtube.com/embed/Iwe6AmxVf7o",
        primaryMuscle: "Chest",
        secondaryMuscles: "Shoulders",
        technique: [
          "Stand in center of cable machine",
          "Keep slight bend in elbows throughout",
          "Bring hands together in front of chest",
          "Squeeze chest at the peak contraction",
        ],
        mistakes: ["Bending elbows too much (turns into a press)", "Using too much weight", "Leaning too far forward"],
      },
    ],
  },

  // ============ BACK ============
  {
    name: "Back",
    icon: "🔙",
    exercises: [
      {
        name: "Pull Ups",
        videoUrl: "https://www.youtube.com/embed/eGo4IYlbE5g",
        primaryMuscle: "Lats",
        secondaryMuscles: "Biceps, Rear Delts",
        technique: [
          "Grip bar slightly wider than shoulder width",
          "Hang with arms fully extended",
          "Pull up until chin is over the bar",
          "Lower with control, full extension at bottom",
        ],
        mistakes: ["Using momentum (kipping)", "Not going to full extension at bottom", "Shrugging shoulders up"],
      },
      {
        name: "Lat Pulldown",
        videoUrl: "https://www.youtube.com/embed/CAwf7n6Luuc",
        primaryMuscle: "Lats",
        secondaryMuscles: "Biceps, Rear Delts",
        technique: [
          "Sit with thighs secured under pads",
          "Grip bar wider than shoulder width",
          "Pull bar down to upper chest",
          "Squeeze shoulder blades together at bottom",
        ],
        mistakes: ["Pulling bar behind neck", "Leaning back too far", "Using arms instead of back"],
      },
      {
        name: "Face Pulls",
        videoUrl: "https://www.youtube.com/embed/rep-qVOkqgk",
        primaryMuscle: "Rear Delts",
        secondaryMuscles: "Traps, Rhomboids",
        technique: [
          "Set cable at face height",
          "Pull rope towards face, separating hands",
          "Keep elbows high throughout movement",
          "Squeeze shoulder blades at the end",
        ],
        mistakes: ["Using too much weight", "Dropping elbows low", "Not externally rotating at the end"],
      },
      {
        name: "Deadlifts",
        videoUrl: "https://www.youtube.com/embed/op9kVnSso6Q",
        primaryMuscle: "Lower Back, Glutes",
        secondaryMuscles: "Hamstrings, Traps, Forearms",
        technique: [
          "Stand with feet hip-width apart",
          "Grip bar just outside legs",
          "Keep back straight, chest up",
          "Drive through heels, extend hips and knees together",
        ],
        mistakes: ["Rounding the lower back", "Letting bar drift away from body", "Hyperextending at the top"],
      },
    ],
  },

  // ============ BICEPS ============
  {
    name: "Biceps",
    icon: "💪",
    exercises: [
      {
        name: "Barbell Curls",
        videoUrl: "https://www.youtube.com/embed/kwG2ipFRgfo",
        primaryMuscle: "Biceps",
        secondaryMuscles: "Forearms",
        technique: [
          "Stand with feet shoulder-width apart",
          "Grip barbell with underhand grip",
          "Keep elbows close to sides",
          "Curl bar up to shoulder level, squeeze biceps",
        ],
        mistakes: ["Swinging body for momentum", "Moving elbows forward", "Not fully extending at bottom"],
      },
      {
        name: "Dumbbell Curls",
        videoUrl: "https://www.youtube.com/embed/ykJmrZ5v0Oo",
        primaryMuscle: "Biceps",
        secondaryMuscles: "Forearms",
        technique: [
          "Stand or sit with dumbbells at sides",
          "Curl one or both dumbbells up",
          "Supinate wrist (turn palm up) as you curl",
          "Lower with control",
        ],
        mistakes: ["Using too much weight", "Fast and uncontrolled reps", "Swinging the weights"],
      },
      {
        name: "Hammer Curls",
        videoUrl: "https://www.youtube.com/embed/zC3nLlEvin4",
        primaryMuscle: "Brachialis",
        secondaryMuscles: "Biceps, Forearms",
        technique: [
          "Hold dumbbells with neutral grip (palms facing each other)",
          "Keep elbows pinned to sides",
          "Curl up while maintaining neutral grip",
          "Lower slowly with control",
        ],
        mistakes: ["Rotating wrists during movement", "Swinging weights up", "Not controlling the negative"],
      },
      {
        name: "Cable Curls",
        videoUrl: "https://www.youtube.com/embed/NFzTWp2qpiE",
        primaryMuscle: "Biceps",
        secondaryMuscles: "Forearms",
        technique: [
          "Stand facing low cable pulley",
          "Grip bar or rope attachment",
          "Keep elbows at sides, curl up",
          "Squeeze at top, lower with control",
        ],
        mistakes: ["Standing too close to machine", "Letting elbows drift forward", "Using body momentum"],
      },
    ],
  },

  // ============ TRICEPS ============
  {
    name: "Triceps",
    icon: "💪",
    exercises: [
      {
        name: "Close Grip Bench Press",
        videoUrl: "https://www.youtube.com/embed/nEF0bv2FW94",
        primaryMuscle: "Triceps",
        secondaryMuscles: "Chest, Shoulders",
        technique: [
          "Lie on bench, grip bar shoulder-width or narrower",
          "Keep elbows tucked close to body",
          "Lower bar to lower chest",
          "Press up by extending elbows",
        ],
        mistakes: ["Grip too narrow (strains wrists)", "Flaring elbows out", "Bouncing bar off chest"],
      },
      {
        name: "Triceps Dips",
        videoUrl: "https://www.youtube.com/embed/6kALZikXxLc",
        primaryMuscle: "Triceps",
        secondaryMuscles: "Chest, Shoulders",
        technique: [
          "Grip parallel bars, arms straight",
          "Keep body upright for triceps focus",
          "Lower until elbows are at 90 degrees",
          "Push up until arms are fully extended",
        ],
        mistakes: ["Going too deep (shoulder strain)", "Leaning too far forward", "Not locking out at top"],
      },
      {
        name: "Triceps Pushdown",
        videoUrl: "https://www.youtube.com/embed/2-LAMcpzODU",
        primaryMuscle: "Triceps",
        technique: [
          "Stand facing cable machine",
          "Grip bar or rope at chest height",
          "Keep elbows pinned to sides",
          "Push down until arms are straight, squeeze",
        ],
        mistakes: ["Letting elbows drift forward", "Using shoulders to push", "Leaning over the weight"],
      },
      {
        name: "Skull Crushers",
        videoUrl: "https://www.youtube.com/embed/d_KZxkY_0cM",
        primaryMuscle: "Triceps",
        technique: [
          "Lie on bench holding bar above chest",
          "Keep upper arms vertical",
          "Bend elbows to lower bar to forehead",
          "Extend elbows to return to start",
        ],
        mistakes: ["Moving elbows back and forth", "Going too heavy too soon", "Lowering bar to wrong position"],
      },
    ],
  },

  // ============ FOREARMS ============
  {
    name: "Forearms",
    icon: "✊",
    exercises: [
      {
        name: "Barbell Wrist Curls",
        videoUrl: "https://www.youtube.com/embed/7AC4VP9C_Mw",
        primaryMuscle: "Forearm Flexors",
        technique: [
          "Sit with forearms resting on thighs",
          "Hold barbell with underhand grip",
          "Let wrists extend down",
          "Curl wrists up, squeezing forearms",
        ],
        mistakes: ["Lifting forearms off thighs", "Using too much weight", "Jerky movements"],
      },
      {
        name: "Reverse Wrist Curls",
        videoUrl: "https://www.youtube.com/embed/A9-ATxNHU60",
        primaryMuscle: "Forearm Extensors",
        technique: [
          "Sit with forearms on thighs, palms down",
          "Let wrists hang over edge",
          "Curl wrists upward",
          "Lower with control",
        ],
        mistakes: ["Going too heavy", "Moving forearms", "Rushing the reps"],
      },
      {
        name: "Cable Wrist Curls",
        videoUrl: "https://www.youtube.com/embed/kVk4Qu0UXIY",
        primaryMuscle: "Forearm Flexors",
        technique: [
          "Kneel facing low cable",
          "Rest forearms on bench",
          "Curl wrists toward you",
          "Lower slowly with control",
        ],
        mistakes: ["Using momentum", "Lifting forearms", "Not full range of motion"],
      },
    ],
  },

  // ============ LEGS ============
  {
    name: "Legs",
    icon: "🦵",
    exercises: [
      {
        name: "Barbell Back Squats",
        videoUrl: "https://www.youtube.com/embed/bEv6CCg2BC8",
        primaryMuscle: "Quadriceps, Glutes",
        secondaryMuscles: "Hamstrings, Core",
        technique: [
          "Bar rests on upper traps",
          "Feet shoulder-width, toes slightly out",
          "Sit back and down, keeping chest up",
          "Go to parallel or below, drive through heels",
        ],
        mistakes: ["Knees caving inward", "Rounding lower back", "Rising on toes"],
      },
      {
        name: "Leg Press",
        videoUrl: "https://www.youtube.com/embed/IZxyjW7MPJQ",
        primaryMuscle: "Quadriceps",
        secondaryMuscles: "Glutes, Hamstrings",
        technique: [
          "Sit with back flat against pad",
          "Place feet shoulder-width on platform",
          "Lower weight until knees are at 90 degrees",
          "Push through heels to extend legs",
        ],
        mistakes: ["Locking knees at top", "Lifting hips off seat", "Going too deep"],
      },
      {
        name: "Leg Curls",
        videoUrl: "https://www.youtube.com/embed/1Tq3QdYUuHs",
        primaryMuscle: "Hamstrings",
        technique: [
          "Lie face down on machine",
          "Pad should be above heels",
          "Curl legs up toward glutes",
          "Lower with control",
        ],
        mistakes: ["Lifting hips off pad", "Using momentum", "Not full range of motion"],
      },
      {
        name: "Leg Extensions",
        videoUrl: "https://www.youtube.com/embed/YyvSfVjQeL0",
        primaryMuscle: "Quadriceps",
        technique: [
          "Sit with back against pad",
          "Pad should be on lower shins",
          "Extend legs until straight",
          "Squeeze quads at top, lower slowly",
        ],
        mistakes: ["Using too much weight", "Jerky movements", "Not controlling the negative"],
      },
      {
        name: "Romanian Deadlifts",
        videoUrl: "https://www.youtube.com/embed/jEy_czb3RKA",
        primaryMuscle: "Hamstrings",
        secondaryMuscles: "Glutes, Lower Back",
        technique: [
          "Hold barbell at hip level",
          "Push hips back while lowering bar",
          "Keep bar close to legs",
          "Feel stretch in hamstrings, then drive hips forward",
        ],
        mistakes: ["Rounding the back", "Bending knees too much", "Not hinging at hips"],
      },
      {
        name: "Calf Raises",
        videoUrl: "https://www.youtube.com/embed/-M4-G8p8fmc",
        primaryMuscle: "Calves",
        technique: [
          "Stand on edge of step or platform",
          "Let heels drop below platform level",
          "Push up onto toes as high as possible",
          "Pause at top, lower slowly",
        ],
        mistakes: ["Bouncing at bottom", "Not full range of motion", "Going too fast"],
      },
    ],
  },

  // ============ STOMACH / ABS ============
  {
    name: "Stomach",
    icon: "🎯",
    exercises: [
      {
        name: "Crunches",
        videoUrl: "https://www.youtube.com/embed/Xyd_fa5zoEU",
        primaryMuscle: "Rectus Abdominis (Upper Abs)",
        technique: [
          "Lie on back with knees bent",
          "Hands behind head (don't pull on neck)",
          "Lift shoulders off ground using abs",
          "Lower with control, don't rest completely",
        ],
        mistakes: ["Pulling on neck with hands", "Using momentum", "Coming up too high"],
      },
      {
        name: "Leg Raises",
        videoUrl: "https://www.youtube.com/embed/l4kQd9eWclE",
        primaryMuscle: "Lower Abs",
        secondaryMuscles: "Hip Flexors",
        technique: [
          "Lie flat or hang from bar",
          "Keep legs straight or slightly bent",
          "Raise legs until perpendicular to floor",
          "Lower slowly with control",
        ],
        mistakes: ["Swinging legs", "Arching lower back", "Using momentum"],
      },
      {
        name: "Plank",
        videoUrl: "https://www.youtube.com/embed/ASdvN_XEl_c",
        primaryMuscle: "Core (All)",
        secondaryMuscles: "Shoulders, Back",
        technique: [
          "Forearms on ground, elbows under shoulders",
          "Body in straight line from head to heels",
          "Engage core, squeeze glutes",
          "Hold position, breathe steadily",
        ],
        mistakes: ["Hips sagging down", "Hips raised too high", "Holding breath"],
      },
      {
        name: "Cable Crunches",
        videoUrl: "https://www.youtube.com/embed/AV5PmSJfl9I",
        primaryMuscle: "Rectus Abdominis",
        technique: [
          "Kneel facing cable machine",
          "Hold rope behind head",
          "Crunch down, bringing elbows toward thighs",
          "Return with control, maintain tension",
        ],
        mistakes: ["Sitting back instead of crunching", "Using arms to pull", "Not controlling the weight"],
      },
    ],
  },
]
