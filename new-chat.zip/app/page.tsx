import Header from "@/components/header"
import MuscleCategory from "@/components/muscle-category"
import { exerciseData } from "@/data/exercises"

export default function Home() {
  return (
    <main className="min-h-screen bg-background">
      <Header />

      <div className="max-w-6xl mx-auto px-4 py-8">
        <h2 className="text-3xl font-bold text-center mb-8 text-foreground">Choose a Muscle Group</h2>

        {/* All muscle categories */}
        <div className="space-y-12">
          {exerciseData.map((category) => (
            <MuscleCategory key={category.name} category={category} />
          ))}
        </div>
      </div>

      {/* Footer */}
      <footer className="text-center py-8 text-muted-foreground border-t border-border mt-12">
        <p>Built for learning proper exercise techniques</p>
      </footer>
    </main>
  )
}
