"use client"

import { useState } from "react"
import ExerciseCard from "./exercise-card"
import type { MuscleGroup } from "@/data/exercises"

interface MuscleCategoryProps {
  category: MuscleGroup
}

export default function MuscleCategory({ category }: MuscleCategoryProps) {
  const [isOpen, setIsOpen] = useState(false)

  return (
    <div className="bg-card rounded-lg border border-border overflow-hidden">
      {/* Category Header - Click to expand */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full px-6 py-4 flex items-center justify-between hover:bg-secondary transition-colors"
      >
        <div className="flex items-center gap-3">
          <span className="text-3xl">{category.icon}</span>
          <h3 className="text-2xl font-bold text-foreground">{category.name}</h3>
        </div>
        <span className="text-primary text-2xl">{isOpen ? "−" : "+"}</span>
      </button>

      {/* Exercises List - Shows when expanded */}
      {isOpen && (
        <div className="p-6 pt-0 grid gap-6 md:grid-cols-2">
          {category.exercises.map((exercise) => (
            <ExerciseCard key={exercise.name} exercise={exercise} />
          ))}
        </div>
      )}
    </div>
  )
}
