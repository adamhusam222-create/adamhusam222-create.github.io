export default function Header() {
  return (
    <header className="bg-card border-b border-border">
      <div className="max-w-6xl mx-auto px-4 py-6">
        <h1 className="text-4xl font-bold text-center">
          <span className="text-primary">Gym</span>
          <span className="text-foreground">Tech</span>
        </h1>
        <p className="text-center text-muted-foreground mt-2">Master proper exercise techniques</p>
      </div>
    </header>
  )
}
