"use client"

import { useState } from "react"
import type { Exercise } from "@/data/exercises"

interface ExerciseCardProps {
  exercise: Exercise
}

export default function ExerciseCard({ exercise }: ExerciseCardProps) {
  const [showDetails, setShowDetails] = useState(false)

  return (
    <div className="bg-secondary rounded-lg border border-border overflow-hidden">
      {/* Exercise Name */}
      <button
        onClick={() => setShowDetails(!showDetails)}
        className="w-full px-4 py-3 flex items-center justify-between hover:bg-muted transition-colors"
      >
        <h4 className="text-lg font-semibold text-foreground">{exercise.name}</h4>
        <span className="text-primary">{showDetails ? "Hide" : "Show"}</span>
      </button>

      {/* Exercise Details */}
      {showDetails && (
        <div className="p-4 space-y-4">
          {/* Video Embed */}
          <div className="aspect-video bg-background rounded-lg overflow-hidden">
            <iframe
              src={exercise.videoUrl}
              title={exercise.name}
              className="w-full h-full"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
            />
          </div>

          {/* Muscles Worked */}
          <div className="bg-background p-3 rounded-lg">
            <p className="text-sm">
              <span className="text-primary font-semibold">Primary: </span>
              <span className="text-foreground">{exercise.primaryMuscle}</span>
            </p>
            {exercise.secondaryMuscles && (
              <p className="text-sm mt-1">
                <span className="text-accent font-semibold">Secondary: </span>
                <span className="text-muted-foreground">{exercise.secondaryMuscles}</span>
              </p>
            )}
          </div>

          {/* Technique Points */}
          <div>
            <h5 className="font-semibold text-primary mb-2">Technique Points:</h5>
            <ul className="space-y-1">
              {exercise.technique.map((point, index) => (
                <li key={index} className="flex items-start gap-2 text-sm text-foreground">
                  <span className="text-green-500">✓</span>
                  {point}
                </li>
              ))}
            </ul>
          </div>

          {/* Common Mistakes */}
          <div>
            <h5 className="font-semibold text-red-400 mb-2">Common Mistakes:</h5>
            <ul className="space-y-1">
              {exercise.mistakes.map((mistake, index) => (
                <li key={index} className="flex items-start gap-2 text-sm text-muted-foreground">
                  <span className="text-red-500">✗</span>
                  {mistake}
                </li>
              ))}
            </ul>
          </div>
        </div>
      )}
    </div>
  )
}
